"""
brain_v3.py
-----------
THE PLASTIC VALUE SYSTEM.

The last wall: the worm couldn't form new goals.
Now it can.

Changes from brain_v2:
  1. PLASTIC CURIOSITY ENGINE — drive weights are learnable
     - w_richness, w_novelty, w_danger update via slow meta-learning
     - New drives can form for unknown signals (w_unknown starts at 0)
     - Drives shift based on cumulative outcome, not single steps

  2. ASSOCIATIVE VALUE LEARNING — classical conditioning
     - Signals that co-occur with food become attractive
     - Signals that co-occur with danger become repulsive
     - The SAME signal can flip from good to bad (preference reversal)

  3. HOMEOSTATIC ENERGY — internal state changes priorities
     - Energy depletes each step, restored by food
     - High energy → explore (novelty drive up)
     - Low energy → exploit (richness drive up, risk tolerance down)
     - Critical energy → desperate (ignore danger to find food)

  4. Everything from brain_v2 (adaptive sensors, neuromodulation, 
     eligibility traces, dual representation)
"""

import numpy as np


class PlasticCuriosityEngine:
    """
    The soul — but now it can CHANGE.

    Drive weights start with innate defaults but shift based on
    experience. This is the difference between a thermostat (fixed
    setpoint) and a living thing (setpoint adapts to context).
    """

    def __init__(self):
        # ── Innate drives (starting values, now MUTABLE) ──
        self.w_novelty  = 0.6
        self.w_richness = 0.3
        self.w_danger   = 0.8

        # ── Learned drives (start at zero, shaped by experience) ──
        self.w_unknown  = 0.0   # value of unknown signals (can go + or -)

        # ── Drive learning parameters ──
        self.DRIVE_LR = 0.0005       # 100x slower than Hebbian learning
        self.DRIVE_DECAY = 0.9999    # slow regression toward innate values
        self.INNATE_NOVELTY  = 0.6   # what we regress toward
        self.INNATE_RICHNESS = 0.3
        self.INNATE_DANGER   = 0.8

        # ── Associative memory for value learning ──
        # Tracks co-occurrence: {signal_type: running_correlation_with_reward}
        self.value_associations = {
            'unknown': 0.0,   # does unknown signal predict good or bad?
        }
        self.ASSOC_LR = 0.005  # association learning rate

        # ── Homeostatic energy system ──
        self.energy = 1.0            # starts full
        self.ENERGY_DECAY = 0.002    # per-step drain
        self.ENERGY_FOOD_RESTORE = 0.15  # how much food restores
        self.ENERGY_CRITICAL = 0.2   # below this → desperate mode

        # ── History for meta-learning ──
        self.drive_history = []
        self.novelty_outcomes = []    # was seeking novelty rewarded?
        self.richness_outcomes = []   # was seeking richness rewarded?
        self.unknown_outcomes = []    # was following unknown rewarded?

    def compute(self, sensors):
        """Compute drives, now modulated by energy and learned values."""
        richness_asym = sensors.get('richness_R', 0) - sensors.get('richness_L', 0)
        novelty_asym  = sensors.get('novelty_R', 0)  - sensors.get('novelty_L', 0)
        danger_asym   = sensors.get('danger_R', 0)   - sensors.get('danger_L', 0)

        forward_richness = sensors.get('richness_F', 0)
        forward_novelty  = sensors.get('novelty_F', 0)
        forward_danger   = sensors.get('danger_F', 0)

        # ── Energy modulation ──
        # Low energy → care more about food, less about novelty
        # High energy → explore freely
        energy_factor = self.energy

        effective_novelty  = self.w_novelty * energy_factor
        effective_richness = self.w_richness * (2.0 - energy_factor)  # inverse: low energy → high food drive
        effective_danger   = self.w_danger * (0.5 + energy_factor * 0.5)  # desperate worms take more risk

        # Direction bias
        direction_bias = (
            effective_richness * richness_asym +
            effective_novelty  * novelty_asym  -
            effective_danger   * danger_asym
        )

        # Add unknown signal influence (learned value)
        unknown_asym = sensors.get('unknown_R', 0) - sensors.get('unknown_L', 0)
        direction_bias += self.w_unknown * unknown_asym

        # Curiosity score
        curiosity_score = (
            effective_novelty  * sensors.get('novelty_here', 0) +
            effective_richness * sensors.get('richness_here', 0) -
            effective_danger   * sensors.get('danger_here', 0) +
            self.w_unknown     * sensors.get('unknown_here', 0)
        )

        # Forward pull
        forward_unknown = sensors.get('unknown_F', 0)
        forward_pull = (
            effective_richness * forward_richness +
            effective_novelty  * forward_novelty  -
            effective_danger   * forward_danger +
            self.w_unknown     * forward_unknown
        )

        return {
            'curiosity_score': float(curiosity_score),
            'direction_bias':  float(direction_bias),
            'forward_pull':    float(forward_pull),
            'energy':          float(self.energy),
            'w_novelty':       float(self.w_novelty),
            'w_richness':      float(self.w_richness),
            'w_danger':        float(self.w_danger),
            'w_unknown':       float(self.w_unknown),
        }

    def update_energy(self, food_reward):
        """Energy drains each step, restored by eating."""
        self.energy -= self.ENERGY_DECAY
        if food_reward > 0:
            self.energy += food_reward * self.ENERGY_FOOD_RESTORE
        self.energy = np.clip(self.energy, 0.0, 1.0)

    def update_associations(self, sensors, reward):
        """
        Classical conditioning — Rescorla-Wagner with explicit pairing detection.

        Key fix: detect SPECIFIC pairings, not just overall reward.
        If unknown signal is present AND danger is present → strong negative.
        If unknown signal is present AND food is present → strong positive.
        This is what real nociceptor + chemosensory integration does.
        """
        unknown_here = sensors.get('unknown_here', 0)
        danger_here = sensors.get('danger_here', 0)
        richness_here = sensors.get('richness_here', 0)

        if unknown_here > 0.01:
            # Standard Rescorla-Wagner: prediction error
            expected = self.w_unknown * unknown_here
            error = reward - expected
            self.value_associations['unknown'] += self.ASSOC_LR * error * unknown_here

            # EXPLICIT PAIRING DETECTION — the key fix
            # When signal co-occurs with danger → strong negative update
            # This is fast aversive conditioning (one-trial learning in real worms)
            # Low thresholds — even mild danger near signal counts
            if danger_here > 0.05 and unknown_here > 0.02:
                # Danger + signal = negative pairing
                pairing_strength = danger_here * unknown_here
                self.w_unknown -= 0.02 * pairing_strength  # direct fast update
                self.value_associations['unknown'] -= 0.05 * pairing_strength

            # When signal co-occurs with rich food → positive update
            if richness_here > 0.2 and unknown_here > 0.02 and danger_here < 0.05:
                pairing_strength = richness_here * unknown_here
                self.w_unknown += 0.005 * pairing_strength  # slower positive (asymmetric — danger learns faster)

            self.unknown_outcomes.append((unknown_here, reward))

    def update_drives(self, sensors, reward, action_was_toward_novelty,
                      action_was_toward_richness):
        """
        Slow meta-learning: shift drive weights based on what works.

        If chasing novelty led to good reward → increase w_novelty
        If chasing richness led to danger → decrease w_richness
        """
        # Track outcomes
        if action_was_toward_novelty:
            self.novelty_outcomes.append(reward)
        if action_was_toward_richness:
            self.richness_outcomes.append(reward)

        # Only update drives every 50 steps (slow)
        if len(self.novelty_outcomes) >= 50:
            avg_novelty_outcome = np.mean(self.novelty_outcomes[-50:])
            self.w_novelty += self.DRIVE_LR * avg_novelty_outcome
            self.novelty_outcomes = self.novelty_outcomes[-50:]

        if len(self.richness_outcomes) >= 50:
            avg_richness_outcome = np.mean(self.richness_outcomes[-50:])
            self.w_richness += self.DRIVE_LR * avg_richness_outcome
            self.richness_outcomes = self.richness_outcomes[-50:]

        # Unknown drive: directly driven by association learning
        # The association value IS the drive — not a weak additive signal
        assoc = self.value_associations['unknown']
        # Exponential moving average: w_unknown drifts toward association value
        self.w_unknown = 0.99 * self.w_unknown + 0.01 * (assoc * 10)
        self.w_unknown = np.clip(self.w_unknown, -1.0, 1.0)

        # Slow regression toward innate values (genetic pull)
        self.w_novelty  = self.DRIVE_DECAY * self.w_novelty + (1 - self.DRIVE_DECAY) * self.INNATE_NOVELTY
        self.w_richness = self.DRIVE_DECAY * self.w_richness + (1 - self.DRIVE_DECAY) * self.INNATE_RICHNESS
        self.w_danger   = self.DRIVE_DECAY * self.w_danger + (1 - self.DRIVE_DECAY) * self.INNATE_DANGER

        # Clamp drives to sane range
        self.w_novelty  = np.clip(self.w_novelty,  0.05, 1.5)
        self.w_richness = np.clip(self.w_richness, 0.05, 1.5)
        self.w_danger   = np.clip(self.w_danger,   0.1,  2.0)

        self.drive_history.append({
            'w_novelty': float(self.w_novelty),
            'w_richness': float(self.w_richness),
            'w_danger': float(self.w_danger),
            'w_unknown': float(self.w_unknown),
            'energy': float(self.energy),
        })

    def get_drive_stats(self):
        return {
            'w_novelty': round(self.w_novelty, 4),
            'w_richness': round(self.w_richness, 4),
            'w_danger': round(self.w_danger, 4),
            'w_unknown': round(self.w_unknown, 4),
            'energy': round(self.energy, 4),
            'assoc_unknown': round(self.value_associations['unknown'], 4),
        }


# ── AdaptiveSensorArray and NerveRingV2 imported from brain_v2 ──
# They don't change. The upgrade is in the value system, not the wiring.
from core.brain_v2 import AdaptiveSensorArray, NerveRingV2
